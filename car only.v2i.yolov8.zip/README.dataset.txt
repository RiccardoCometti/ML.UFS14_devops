# car only > 2024-11-21 9:41am
https://universe.roboflow.com/deeplearningproject-xjt7f/car-only-gopq6

Provided by a Roboflow user
License: CC BY 4.0

